package com.clone.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZomatoCloneApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZomatoCloneApplication.class, args);
		System.out.println("SprinbBoot is UP and RUNNING");
	}

}
