package com.clone.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.clone.app.repo.RestaurantRepo;
import com.clone.app.exception.DuplicateRestaurantNameException;
import com.clone.app.model.Restaurant;

@Service
public class RestaurantServiceImpl {
	
	@Autowired
	RestaurantRepo rr;
	
	public Restaurant post(Restaurant r) {
        if (isRestaurantNameExists(r.getName())) {
            throw new DuplicateRestaurantNameException("Restaurant with the same name already exists");
        }
        return rr.save(r);
    }

	
	public List<Restaurant> getall() {
		return rr.findAll();
	}

	
	public Restaurant put(Restaurant r) {
		return rr.save(r);
	}

	
	public Optional<Restaurant> getbyid(long id) {
		if(rr.existsById(id)) {
			return rr.findById(id);
		}
		return null;
	}

	
	public Optional<Restaurant> delete(long id) {
		Optional<Restaurant> r=rr.findById(id);
		if(rr.existsById(id)) {
			rr.deleteById(id);
			return r;
		}
		return null;
	}


	public boolean isRestaurantNameExists(String name) {
		// TODO Auto-generated method stub
		
	        return rr.existsByName(name);
	    
	}
	
}
