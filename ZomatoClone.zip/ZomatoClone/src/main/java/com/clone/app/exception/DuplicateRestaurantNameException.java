package com.clone.app.exception;

public class DuplicateRestaurantNameException extends RuntimeException {

    public DuplicateRestaurantNameException(String message) {
        super(message);
    }
}
