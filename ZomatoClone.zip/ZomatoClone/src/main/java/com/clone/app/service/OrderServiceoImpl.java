package com.clone.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.clone.app.model.Order;
import com.clone.app.repo.OrderRepo;
@Service
public class OrderServiceoImpl {
	
	@Autowired
	private OrderRepo or;
	
	
	public Order post(Order o) {
		return or.save(o);
	}

	
	public List<Order> get() {
		return or.findAll();
	}

	
	public Order put(Order o) {
		return or.save(o);
	}

	
	public Optional<Order> getbyid(long id) {
		if(or.existsById(id)) {
			return or.findById(id);
		}
		return null;
	}

}
