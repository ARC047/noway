package com.clone.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.clone.app.model.Dish;
import com.clone.app.repo.DishRepo;
@Service
public class DishServiceImpl {

	@Autowired
	DishRepo dr;
	
	public Dish post(Dish d) {
		return dr.save(d);
	}

	
	public List<Dish> getall() {
		return dr.findAll();
	}

	
	public Dish put(Dish d) {
		return dr.save(d);
	}

	
	public Optional<Dish> getbyid(long id) {
		if(dr.existsById(id)) {
			return dr.findById(id);
		}
		return null;
	}

	
	public Optional<Dish> delete(long id) {
		Optional<Dish> r=dr.findById(id);
		if(dr.existsById(id)) {
			dr.deleteById(id);
			return r;
		}
		return null;
	}
}
