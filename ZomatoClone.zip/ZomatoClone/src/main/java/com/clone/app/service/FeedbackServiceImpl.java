package com.clone.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.clone.app.model.Feedback;
import com.clone.app.repo.FeedbackRepo;
@Service
public class FeedbackServiceImpl {
	
	@Autowired
	private FeedbackRepo fr;
	
	
	public Feedback post(Feedback f) {
		return fr.save(f);
	}

	
	public List<Feedback> get() {
		return fr.findAll();
	}

	
	public Feedback put(Feedback f) {
		return fr.save(f);
	}

	
	public Optional<Feedback> getbyid(long id) {
		if(fr.existsById(id)) {
			return fr.findById(id);
		}
		return null;
	}
}
