package com.clone.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.clone.app.model.Customer;
import com.clone.app.repo.CustomerRepo;
@Service
public class CustomerServiceImpl {
	
	@Autowired
	CustomerRepo cr;
	
	public Customer post(Customer c) {
		return cr.save(c);
	}

	
	public List<Customer> getall() {
		return cr.findAll();
	}

	
	public Customer put(Customer c) {
		return cr.save(c);
	}

	
	public Optional<Customer> getbyid(long id) {
		if(cr.existsById(id)) {
			return cr.findById(id);
		}
		return null;
	}

	
	public Optional<Customer> delete(long id) {
		Optional<Customer> c=cr.findById(id);
		if(cr.existsById(id)) {
			cr.deleteById(id);
			return c;
		}
		return null;
	}
}
