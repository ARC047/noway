package com.clone.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.clone.app.exception.DuplicateRestaurantNameException;
import com.clone.app.model.Restaurant;
import com.clone.app.service.RestaurantServiceImpl;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;

@RestController
@RequestMapping("api/v1/home/restaurant")
public class restaurantController {
	
	@Autowired
	private RestaurantServiceImpl rs;
	
	
	
	@GetMapping("/get")
	public ResponseEntity<?> getall(){
		return new ResponseEntity<List<Restaurant>>(rs.getall(),HttpStatus.OK);
	}
	
	@PostMapping("/post")
	public ResponseEntity<?> createRestaurant(@RequestBody Restaurant r) {
	        try {
	            Restaurant savedRestaurant = rs.post(r);
	            return new ResponseEntity<>(savedRestaurant, HttpStatus.CREATED);
	        } catch (DuplicateRestaurantNameException e) {
	            return new ResponseEntity<>("Restaurant with the same name already exists", HttpStatus.CONFLICT);
	        } catch (Exception e) {
	            return new ResponseEntity<>("Failed to create restaurant", HttpStatus.INTERNAL_SERVER_ERROR);
	        }
	    }
	@PutMapping("/put")
	public ResponseEntity<?> put(@RequestBody Restaurant r){
		return new ResponseEntity<Restaurant>(rs.put(r),HttpStatus.OK);
	}
	
	@GetMapping("/getById")	//USE "/getById?id=123" for url
	public ResponseEntity<?> getbyid(@RequestParam("id") long id) {
	    Optional<Restaurant> r = rs.getbyid(id);
	    if (!r.isPresent()) { // Check if the Optional is empty
	        return new ResponseEntity<String>("No such Restaurant id to get", HttpStatus.NOT_FOUND);
	    }
	    return new ResponseEntity<Optional<Restaurant>>(r, HttpStatus.OK);
	}
	@DeleteMapping("/deleteById")//USE "/deleteById?id=123" for url
	public ResponseEntity<?> delete(@RequestParam("id") long id){
		Optional<Restaurant> r=rs.delete(id);
		if(r==null) {
			return new ResponseEntity<String>("no such restaurant id to delete",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Optional<Restaurant>>(r,HttpStatus.OK);
	}
	
	@Autowired
    private EntityManager entityManager; // Inject the entity manager

    @GetMapping("/getByName/{name}")
    public ResponseEntity<List<Restaurant>> getByName(@PathVariable("name") String name) {
        // Use a native SQL query to retrieve data based on the name
        String sql = "SELECT * FROM restaurant WHERE restaurant_name = :name";
        Query query = entityManager.createNativeQuery(sql, Restaurant.class);
        query.setParameter("name", name);
        
        @SuppressWarnings("unchecked")
        List<Restaurant> restaurants = query.getResultList();

        if (restaurants.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<>(restaurants, HttpStatus.OK);
    }
    
    @GetMapping("/getByLocation/{location}")
    public ResponseEntity<List<Restaurant>> getByLocation(@PathVariable("location") String location) {
        String sql = "SELECT * FROM restaurant WHERE restaurant_loc = :location";
        Query query = entityManager.createNativeQuery(sql, Restaurant.class);
        query.setParameter("location", location);

        @SuppressWarnings("unchecked")
        List<Restaurant> restaurants = query.getResultList();

        if (restaurants.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<>(restaurants, HttpStatus.OK);
    }
    
    @GetMapping("/getByCategory/{category}")
    public ResponseEntity<List<Restaurant>> getByCategory(@PathVariable("category") String category) {
        String sql = "SELECT * FROM restaurant WHERE restaurant_cat = :category";
        Query query = entityManager.createNativeQuery(sql, Restaurant.class);
        query.setParameter("category", category);

        @SuppressWarnings("unchecked")
        List<Restaurant> restaurants = query.getResultList();

        if (restaurants.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<>(restaurants, HttpStatus.OK);
    }
}