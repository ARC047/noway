package com.orangehrm.pac;

import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;


import java.io.File;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;


import io.github.bonigarcia.wdm.WebDriverManager;

public class assignment {
	private WebDriver driver;
	int count=0;
	ExtentReports extent;
	ExtentTest test;
	ExtentSparkReporter spark;
	@BeforeClass
	public void extentreportInitialise() {
		//Report with  tests Making
		extent=new ExtentReports();
		spark=new ExtentSparkReporter("./reports/"+"ohrm_report.html");
		extent.attachReporter(spark);
	}
	@BeforeMethod
	  public void launch() {
		  System.out.println("Before Method");
		  WebDriverManager.chromedriver().setup();
		  driver=new ChromeDriver();
		  
		  driver.manage().window().maximize();
		  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(7));
			 
		  
	  }
	
	//Login Test Automation
	@Test(dataProvider="dp1",priority=1)
	public void orangehrmLogin(String uname,String pword){
		count+=1;
		driver.get("https://opensource-demo.orangehrmlive.com");
		driver.findElement(By.name("username")).sendKeys(uname);
		driver.findElement(By.name("password")).sendKeys(pword);
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		//test is linked for report creating
		test=extent.createTest("Login :"+Integer.toString(count)+", login to Orangehrm and verify the home page is displayed");
		try {
		Boolean searchdispalyed=driver.findElement(By.xpath("//input[@placeholder='Search']")).isDisplayed();
		Assert.assertEquals(searchdispalyed, true);
		 if (searchdispalyed.equals(true))
		 {
			 test.pass("Orange HRm Homepage is displayed");
			 System.out.println("Login Successfull");
		 }
		 else
		 {
			 System.out.println("Login unsuccessfull");
		 }	
		}
		catch(Exception e) {
			
			
			TakesScreenshot ts =(TakesScreenshot)driver;
			 
			 File sourcefile=ts.getScreenshotAs(OutputType.FILE);
			 File destfile=new File("./screenshots/"+"orangehrm_homeFailLogin"+Integer.toString(count)+".png");
			 
			 try {
				 FileUtils.copyFile(sourcefile,destfile);
			 }
			 catch(Exception e1)
			 {
				 e1.printStackTrace();
			 }
			test.fail("Orange HRm Homepage is NOT displayed");
			test.addScreenCaptureFromPath("/home/ubuntu/eclipse-workspace/orangehrm/screenshots/orangehrm_homeFailLogin"+Integer.toString(count)+".png");
			System.out.println("Login error: " + e.getMessage());
			System.out.println("WRONG CREDENTIALS");
			
		}
		extent.flush();
		
		}
	
	//Logout Test
	@Test(priority=2)
	public void orangehrmLogout() {
		driver.get("https://opensource-demo.orangehrmlive.com");
		driver.findElement(By.name("username")).sendKeys("Admin");
		driver.findElement(By.name("password")).sendKeys("admin123");
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		driver.findElement(By.cssSelector(".oxd-userdropdown-tab")).click();
		
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(10));
		
		WebElement ele=driver.findElement(By.linkText("Logout"));
		wait.until(ExpectedConditions.elementToBeClickable(ele));
		ele.click();
		
		Boolean logindispalyed=driver.findElement(By.xpath("//h5")).isDisplayed();
		Assert.assertEquals(logindispalyed, true);
		if (logindispalyed.equals(true))
		 {
			 System.out.println("Logout Successful");
		 }
		 else
		 {
			 System.out.println("Logout unsuccessful");
		 }	
	}
	
	//Add Employee Automation
	@Test(dataProvider="dp3",priority=3)
	public void orangehrmAddEmployee(String fname,String mname,String lname,String uname) throws InterruptedException  {
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/pim/addEmployee");
		driver.findElement(By.name("username")).sendKeys("Admin");
		driver.findElement(By.name("password")).sendKeys("admin123");
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		driver.findElement(By.xpath("//input[@name='firstName']")).sendKeys(fname);
		driver.findElement(By.xpath("//input[@name='middleName']")).sendKeys(mname);
		driver.findElement(By.xpath("//input[@name='lastName']")).sendKeys(lname);
		
		//emplyeeID is autofilled by site and not interactable
		//WebElement empID = driver.findElement(By.xpath("//*[@id='app']/div[1]/div[2]/div[2]/div/div/form/div[1]/div[2]/div[1]/div[2]/div/div/div[2]/input"));
     	//empID.sendKeys("1109");
		
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div[2]/div[2]/div/label/span")).click();
		Thread.sleep(3000);	
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div[2]/div[3]/div/div[1]/div/div[2]/input")).sendKeys(uname);

		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("window.scrollTo(0,document.body.scrollHeight)");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div[2]/div[3]/div/div[2]/div/div[2]/div[1]/div[2]/div/label")).click();
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div[2]/div[4]/div/div[1]/div/div[2]/input")).sendKeys("a12345678");
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div[2]/div[4]/div/div[2]/div/div[2]/input")).sendKeys("a12345678");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[@type='submit']")).click();		
		Thread.sleep(7000);
		String actualEmployee = driver.findElement(By.xpath("//h6[@class='oxd-text oxd-text--h6 --strong']")).getText();
		String expectedemployee = fname+" "+lname;
		
		
		
		try {
		Assert.assertEquals(actualEmployee,expectedemployee);
		if (actualEmployee.equalsIgnoreCase(expectedemployee))
		 {	
			 System.out.println("Add Employee Successful");
		 }
		 else
		 {
			 System.out.println("Add Employee unsuccessful");
		 }	
		}
		catch(Exception e) {
			TakesScreenshot ts =(TakesScreenshot)driver;
			 
			 File sourcefile=ts.getScreenshotAs(OutputType.FILE);
			 File destfile=new File("./screenshots/"+"orange_AddEmployee_Fail"+actualEmployee+".png");
			 
			 try {
				 FileUtils.copyFile(sourcefile,destfile);
			 }
			 catch(Exception e1)
			 {
				 e1.printStackTrace();
			 }
			 
			System.out.println("Login error: " + e.getMessage());
			System.out.println("WRONG CREDENTIALS");
		}
		
		
	}
	//DataProvider for Login Test
	@DataProvider
	public Object[][] dp1() {
		return new Object[][] {
			//blank username
		      new Object[] { "", "aswd" },
		    //blank password
		      new Object[] { "qwerty","" },
		    //invalid username
		      new Object[] { "Admin", "1234" },
		    //invalid password
		      new Object[] { "ABHI", "1234" },
		    //valid username & password
		      new Object[] {"Admin","admin123"}
		    };
    }
	private Object[] generateRandomData() {
        String firstName = RandomStringUtils.randomAlphabetic(7);
        String lastName = RandomStringUtils.randomAlphabetic(1);
        String username = RandomStringUtils.randomAlphabetic(5);
        String password = RandomStringUtils.randomAlphanumeric(8);
        
        return new Object[] { firstName, lastName, username, password };
    }
	//DataProvider for Add Employee Test
	@DataProvider
	public Object[][] dp3() {
		return new Object[][] {
			//Data 1
		      generateRandomData(),
		    //Data 2
		      generateRandomData(),
		  
		    };
    }
	@AfterMethod
	  public void quit() {
		  
		  driver.quit();
		  System.out.println("After Method");
	  }
}
