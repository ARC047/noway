package com.ui.stepDefinitions;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.ui.page_objects.scenario3;
import com.ui.utilities.readConfig;

import io.cucumber.java.AfterAll;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class TS_3 {
	
	private static WebDriver driver;
	private ScreenshotHooks sh;
	private scenario3 sc3;

	readConfig rd = new readConfig();
	private String shoeurl = rd.getshoeurl();
	private String screenshotFolder = rd.getscreenshotpath();
	
	private JavascriptExecutor js;
	private ChromeOptions options;
	@Given("Launch the browser")
	public void launch_the_browser() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
		  WebDriverManager.chromedriver().setup();
		  options= new ChromeOptions();
	      options.addArguments("--disable-popup-blocking");
	      driver = new ChromeDriver(options);
		  //driver=new ChromeDriver();
		  driver.manage().window().maximize();
		  //driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

		  sc3=new scenario3(driver);
		  sh= new ScreenshotHooks(driver);
	    //throw new io.cucumber.java.PendingException();
	}

	@And("Navigate to the URL")
	public void navigate_to_the_url() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
		  driver.get(shoeurl);
		  //driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(15));
		  Thread.sleep(5000);
		  ((JavascriptExecutor) driver).executeScript("window.stop();");
		  driver.navigate().refresh();
	    //throw new io.cucumber.java.PendingException();
	}

	@When("Navigate to a product list page")
	public void navigate_to_a_product_list_page() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
		//POM used
		  js=(JavascriptExecutor)driver;
		  sc3.hovermens();
		  sc3.selectCowboy();
		  Thread.sleep(5000);
	    //throw new io.cucumber.java.PendingException();
	}

	@And("Check the checkbox with rating : {int}")
	public void check_the_checkbox_with_rating(Integer rating) throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
		long pageHeight = (Long) js.executeScript("return document.body.scrollHeight;");
	      System.out.println("Total page height: " + pageHeight + " pixels");
		  js.executeScript("window.scrollTo(0,2020)");
		  Thread.sleep(8000);
		  
		  sc3.checkboxrating(rating);
		  Thread.sleep(5000);
	    //throw new io.cucumber.java.PendingException();
	}

	@Then("Verify all elements are with the rating : {int}")
	public void verify_all_elements_are_with_the_same_rating(Integer rating) {
	    // Write code here that turns the phrase above into concrete actions
		//Verify Rating is Reflected in the Prducts
		  js.executeScript("window.scrollTo(2000,270)");
		  Boolean verify = sc3.verifyrating(rating);
		  
		  if (verify.equals(true)) {
			    
			    System.out.println("Verification  Successfull");
			} else {
			    
			    System.out.println("Verification  unsuccessfull");
			}
		  
	    //throw new io.cucumber.java.PendingException();
	}

//	@AfterAll
//	public static void close_the_browser() throws InterruptedException {
//	    // Write code here that turns the phrase above into concrete actions
//		driver.quit();
//		Thread.sleep(2000);
//	    //throw new io.cucumber.java.PendingException();
//	}
}
