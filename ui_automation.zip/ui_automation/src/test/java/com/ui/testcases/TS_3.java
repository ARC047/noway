package com.ui.testcases;

import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.ui.page_objects.scenario3;
import com.ui.utilities.readConfig;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;

import java.io.File;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterClass;

public class TS_3 {
	
	
	readConfig rd = new readConfig();
	private String shoeurl = rd.getshoeurl();
	private String screenshotFolder = rd.getscreenshotpath();
	
	private WebDriver driver;
	private JavascriptExecutor js;
	private ChromeOptions options;
	ExtentReports extent;
	ExtentTest test;
	ExtentSparkReporter spark;
	String timestamp=new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
	String reportname="Test-Report-TC5"+timestamp+".html";
	@BeforeClass
	public void extentreportInitialise() {
		//Report with  tests Making
		extent=new ExtentReports();
		spark=new ExtentSparkReporter("./reports/"+reportname);
		extent.attachReporter(spark);
	}
  @Test(priority = 1)
  public void PagenoNavigationChecker() throws InterruptedException {
	  
	  
	  //test is linked for report creating
	  test=extent.createTest("Test Case for Page No Selection"+timestamp);
	  //POM used
	  scenario3 sc3=new scenario3(driver);
	  sc3.hoverkids();
	  js=(JavascriptExecutor)driver;
	  sc3.selectBacktoSchool();
	  Thread.sleep(3000);
	  js.executeScript("window.scrollTo(0,650)");
	  Thread.sleep(2000);
	  sc3.selectpage2();
	  //Verifying Page changes
	  Boolean verify1=sc3.verifypage2();
	  
	  //initialization for screeshot capture
	  TakesScreenshot ts =(TakesScreenshot)driver;
	  File sourcefile1=ts.getScreenshotAs(OutputType.FILE);
	  String timestamp1=new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
	  String screenshot1="Page_2_"+timestamp1+".png";
	  File destfile1=new File("./screenshots/"+screenshot1);
	  try {
	  FileUtils.copyFile(sourcefile1,destfile1);
	  }
	  catch(Exception e1)
	  {
	  e1.printStackTrace();
	  }
	  
	  if (verify1.equals(true)) {
		    test.pass("Page 2 is displayed", MediaEntityBuilder.createScreenCaptureFromPath(screenshotFolder+screenshot1).build());
		    System.out.println("Verification page:2  Successfull");
		} else {
		    test.fail("Page 2 is NOT displayed", MediaEntityBuilder.createScreenCaptureFromPath(screenshotFolder+screenshot1).build());
		    System.out.println("Verification page:2  unsuccessfull");
		}
	  Thread.sleep(2000);
	  
	  sc3.selectpage3();
	  //Verify next page selection
	  Boolean verify2=sc3.verifypage3();
	  
	  File sourcefile2=ts.getScreenshotAs(OutputType.FILE);
	  String timestamp2=new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
	  String screenshot2="Page_3_"+timestamp2+".png";
	  File destfile2=new File("./screenshots/"+screenshot2);
	  try {
	  FileUtils.copyFile(sourcefile2,destfile2);
	  }
	  catch(Exception e1)
	  {
	  e1.printStackTrace();
	  }
	  if (verify2.equals(true)) {
		    test.pass("Page 3 is displayed", MediaEntityBuilder.createScreenCaptureFromPath(screenshotFolder+screenshot2).build());
		    System.out.println("Verification page:3  Successfull");
		} else {
		    test.fail("Page 3 is NOT displayed", MediaEntityBuilder.createScreenCaptureFromPath(screenshotFolder+screenshot2).build());
		    System.out.println("Verification page:3  unsuccessfull");
		}
	  
  }
  
  @Test(priority = 2)
  public void ProductRatingChecker() throws InterruptedException {
	  
	  //test is linked for report creating
	  test=extent.createTest("Test Case for Rating Check Selection"+timestamp);
	  //POM used
	  js=(JavascriptExecutor)driver;
	  scenario3 sc3=new scenario3(driver);
	  sc3.hovermens();
	  sc3.selectCowboy();
	  Thread.sleep(3000);
	  long pageHeight = (Long) js.executeScript("return document.body.scrollHeight;");
      System.out.println("Total page height: " + pageHeight + " pixels");
	  js.executeScript("window.scrollTo(0,2000)");
	  Thread.sleep(3000);
	  sc3.checkboxrating(4);
	  Thread.sleep(3000);
	  //Verify Rating is Reflected in the Prducts
	  Boolean verify = sc3.verifyrating(4);
	  js.executeScript("window.scrollTo(2000,250)");
	//initialization for screeshot capture
	  TakesScreenshot ts =(TakesScreenshot)driver;
	  File sourcefile1=ts.getScreenshotAs(OutputType.FILE);
	  String timestamp1=new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
	  String screenshot1="Rating_"+timestamp1+".png";
	  File destfile1=new File("./screenshots/"+screenshot1);
	  try {
	  FileUtils.copyFile(sourcefile1,destfile1);
	  }
	  catch(Exception e1)
	  {
	  e1.printStackTrace();
	  }
	  
	  if (verify.equals(true)) {
		    test.pass("All Products are Rating 4", MediaEntityBuilder.createScreenCaptureFromPath(screenshotFolder+screenshot1).build());
		    System.out.println("Verification  Successfull");
		} else {
		    test.fail("All Products are not Rating 4", MediaEntityBuilder.createScreenCaptureFromPath(screenshotFolder+screenshot1).build());
		    System.out.println("Verification  unsuccessfull");
		}
	  
  }
  @BeforeMethod
  public void beforeMethod() throws InterruptedException {
	  
	  
	  WebDriverManager.chromedriver().setup();
	  options= new ChromeOptions();
      options.addArguments("--disable-popup-blocking");
      driver = new ChromeDriver(options);
	  //driver=new ChromeDriver();
	  driver.manage().window().maximize();
	  //driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  System.out.println(shoeurl);
	  Thread.sleep(2000);
	  driver.get(shoeurl);
	  //driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(15));
	  Thread.sleep(5000);
	  ((JavascriptExecutor) driver).executeScript("window.stop();");
	  driver.navigate().refresh();
  }
  

  @AfterMethod
  public void afterMethod() {
	  extent.flush();
	  driver.quit();
  }

  

  @AfterClass
  public void afterClass() {
  }

}
