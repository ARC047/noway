package com.ui.utilities;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class readConfig {
	Properties prob;
	
	public readConfig() {
		try 
		{
		InputStream input=new FileInputStream("/home/ubuntu/eclipse-workspace/ui_automation/configuration/shoe.properties");
		prob=new Properties();
		prob.load(input);
		}
		catch(Exception e)
		{
			System.out.println("Exception is"+e.getMessage());
		}
	}
	
	public String getshoeurl() {
		String shoeurl=prob.getProperty("shoeurl");
		return shoeurl;
	}
	
	public String getexcelpath() {
		String excelpath=prob.getProperty("inputdata");
		return excelpath;
	}
	
	public String getscreenshotpath() {
		String excelpath=prob.getProperty("screenshotFolder");
		return excelpath;
	}
	
}