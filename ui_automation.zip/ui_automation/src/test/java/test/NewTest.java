package test;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterClass;

public class NewTest {
    WebDriver driver;

    @BeforeMethod
    public void beforeMethod() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver(); // Initialize the driver
        driver.manage().window().maximize();
        driver.get("https://www.shoecarnival.com/");
    }

    @AfterMethod
    public void afterMethod() {
        driver.quit();
    }

    @Test()
    public void f(Integer n, String s) throws InterruptedException {
    	driver.navigate().refresh();
        driver.findElement(By.xpath("//span[@class='jss61 jss64']")).click();;
//        Actions act1 = new Actions(driver);
//        act1.moveToElement(ele1).perform();
        Thread.sleep(2000);
        driver.findElement(By.linkText("Login")).click();
        Thread.sleep(2000);
    }

    

    @BeforeClass
    public void beforeClass() {
    }

    @AfterClass
    public void afterClass() {
    }
}