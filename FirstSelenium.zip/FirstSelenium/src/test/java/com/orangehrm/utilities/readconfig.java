package com.orangehrm.utilities;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

public class readconfig {
	Properties prob;
	
	public readconfig() {
		try 
		{
		InputStream input=new FileInputStream("/home/ubuntu/eclipse-workspace/FirstSelenium/configuration/ohrmData.properties");
		prob=new Properties();
		prob.load(input);
		}
		catch(Exception e)
		{
			System.out.println("Exception is"+e.getMessage());
		}
	}
	
	public String getohrmurl() {
		String ohrmurl=prob.getProperty("ohrmurl");
		return ohrmurl;
	}
	
	public String getexcelpath() {
		String excelpath=prob.getProperty("inputdata");
		return excelpath;
	}
}
