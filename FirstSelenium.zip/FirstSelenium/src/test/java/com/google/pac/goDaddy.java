package com.google.pac;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;
public class goDaddy {
    private WebDriver driver;
    @BeforeMethod
    public void setup() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.godaddy.com/");
    }
    @Test
    public void Validation() {
        String actualTitle = driver.getTitle();
        String expectedTitle = "Domain Names, Websites, Hosting & Online Marketing Tools - GoDaddy IN";
        Assert.assertEquals(actualTitle,expectedTitle , "Title validation failed");

        String actualUrl = driver.getCurrentUrl();
        String expectedUrl = "https://www.godaddy.com/en-in";
        Assert.assertEquals(actualUrl, expectedUrl, "URL validation failed");
    
        String pageSource = driver.getPageSource();
        String pageTitle = "GoDaddy";
        Assert.assertTrue(pageSource.contains(pageTitle), "Page title validation in page source failed");
    }
    @AfterMethod
    public void CloseBrowser() { 
        driver.quit();
    }
}