package com.google.pac;

import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class lab006 {
	public static void main(String[] args) throws InterruptedException {
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://demo.opencart.com/");
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		/*
		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(By.linkText("Login")).click();
		driver.findElement(By.id("input-email")).sendKeys("@@@");
		driver.findElement(By.id("input-password")).sendKeys("@@@");
		*/
		driver.findElement(By.linkText("Components")).click();
		driver.findElement(By.linkText("Monitors (2)")).click();
		
		Select show = new Select(driver.findElement(By.xpath("//*[@id=\"input-limit\"]")));
        show.selectByVisibleText("25");
        JavascriptExecutor js = (JavascriptExecutor)driver;
        js.executeScript("window.scrollTo(0,document.body.scrollHeight)");
        Thread.sleep(3000);
        driver.findElement(By.xpath("//*[@id=\"product-list\"]/div[1]/form/div/div[2]/div[2]/button[1]")).click();
        Thread.sleep(3000);
        js.executeScript("window.scrollTo(0,2000)");
        Thread.sleep(3000);
        driver.findElement(By.linkText("Specification")).click();
        Thread.sleep(2000);
        String specname = driver.findElement(By.xpath("//*[@id=\"tab-specification\"]/div/table/tbody/tr/td[1]")).getText();
        String specvalue = driver.findElement(By.xpath("//*[@id=\"tab-specification\"]/div/table/tbody/tr/td[2]")).getText();
        System.out.println(specname);
        System.out.println(specvalue);
        js.executeScript("window.scrollTo(2000,0)");
        Thread.sleep(2000);
        driver.findElement(By.xpath("//*[@id=\"content\"]/div[1]/div[2]/form/div/button[1]")).click();
        //driver.findElement(By.xpath("//*[@id=\"search\"]/input")).sendKeys("Mobile");
        driver.findElement(By.xpath("//*[@id=\"search\"]/button")).click();
        driver.findElement(By.xpath("//*[@id=\"input-description\"]")).click();
        driver.findElement(By.linkText("Phones & PDAs")).click();
        driver.findElement(By.linkText("HTC Touch HD")).click();
        WebElement qntty = driver.findElement(By.id("input-quantity"));
        qntty.clear();
        qntty.sendKeys("3");
        driver.findElement(By.id("button-cart")).click();
        Thread.sleep(1500);
        WebElement divElement = driver.findElement(By.xpath("(//div)[1]"));
        String divText = divElement.getText();
        System.out.println("Alert of Add Cart: " + divText);
        Thread.sleep(10000);
		driver.findElement(By.xpath("//*[@id=\"header-cart\"]/div/button")).click();
		//FURTHER STEPS NOT POSSIBLE AS LOGIN IN IS NOT POSSIBLE IN THE SITE
		
		
	}
}
