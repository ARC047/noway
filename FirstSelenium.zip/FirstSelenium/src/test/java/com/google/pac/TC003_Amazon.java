package com.google.pac;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TC003_Amazon {
	private WebDriver driver;
	@BeforeClass
	  public void launch() {
		  System.out.println("Before Method");
		  WebDriverManager.chromedriver().setup();
		  driver=new ChromeDriver();
		  driver.get("https://www.amazon.in/");
		  driver.manage().window().maximize();
	  }
	@Test(dataProvider="dp")
	public void amazonAutomated(String S) throws InterruptedException {		
			
			System.out.println("Title of the page: "+driver.getTitle());
			driver.findElement(By.id("nav-hamburger-menu")).click();
			driver.findElement(By.xpath(S)).click();
			Thread.sleep(3000);
			System.out.println("Title of current page: "+driver.getTitle());
			String pgtitle = driver.getTitle();
			Assert.assertEquals(driver.getTitle(), pgtitle);
			Thread.sleep(3000);
			driver.navigate().back();
			System.out.println("Title of current page: "+driver.getTitle());
			String pgtitle1 = driver.getTitle();
			Assert.assertEquals(driver.getTitle(), pgtitle1);
		  }
		  
	@DataProvider
	public Object[] dp() {
		String path1="//*[@id=\"hmenu-content\"]/ul[1]/li[3]";
		String path2="//*[@id=\"hmenu-content\"]/ul[1]/li[7]";
		String path3="//*[@id=\"hmenu-content\"]/ul[1]/li[4]";
        return new Object[]{path1,path2,path3};
    }
	@AfterClass
	  public void quit() {
		  driver.quit();
		  System.out.println("After Method");
	  }
}
