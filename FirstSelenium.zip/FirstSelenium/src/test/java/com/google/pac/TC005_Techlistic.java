package com.google.pac;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TC005_Techlistic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();
		WebDriver driver= new ChromeDriver();
		driver.get("https://www.techlistic.com/p/selenium-practice-form.html");
		driver.manage().window().maximize();
		//Firstname and Lastname
		driver.findElement(By.name("firstname")).sendKeys("Abhinav");
		driver.findElement(By.name("lastname")).sendKeys("C Ramesh");
		//Select Sex
		driver.findElement(By.id("sex-0")).click();
		//Select experience
		driver.findElement(By.id("exp-3")).click();
		//Select DOB
		driver.findElement(By.id("datepicker")).sendKeys("10-11-2000");
		//Select Profession 
		driver.findElement(By.id("profession-1")).click();
		//Select tools
		driver.findElement(By.xpath("//*[@id='tool-1']")).click();
		driver.findElement(By.xpath("//*[@id='tool-2']")).click();
		//Select continent
		Select continent = new Select(driver.findElement(By.id("continents")));
        continent.selectByVisibleText("Asia");

        //select commands multiple
        Select commands = new Select(driver.findElement(By.id("selenium_commands")));
        commands.selectByVisibleText("Browser Commands");
        commands.selectByVisibleText("Switch Commands");
        //submit
        driver.findElement(By.id("submit")).click();


        driver.quit();
				

	}

}
