package com.google.pac;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Sleeper;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class testforUber {
  @Test
  public void f() throws InterruptedException {
	  WebDriver driver;
	  WebDriverManager.chromedriver().setup();
	  driver=new ChromeDriver();	  
	  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  driver.get("https://www.shoecarnival.com/mens/boots/cowboy_and_western_boots");
	  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	  
	  driver.navigate().refresh();
	  Thread.sleep(2000);
	  JavascriptExecutor js= (JavascriptExecutor)driver;
	  js.executeScript("window.scrollTo(0,2000)");
	  Thread.sleep(2000);
	  //driver.findElement(By.xpath("//*[@id=\"bx-close-inside-2266899\"]/svg")).click();
	  Thread.sleep(2000);
	  driver.findElement(By.linkText("4 Star")).click();
	 driver.quit();
  }
}
