package com.google.pac;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class quikrPageObjects {
WebDriver driver;
	
	By qkrLogRegButton=By.linkText("Login/Register");
	By allowButton = By.xpath("/html/body/div[8]/div[2]/div[2]/button[2]");
	By popupNumber = By.xpath("//*[@id=\"newLoginSignUpModal\"]/div/div/div/div/form/div[1]/div/input");
	By popupContinue = By.linkText("Continue");
	
	public void clickLoginReg()
	{
		driver.findElement(qkrLogRegButton).click();
	}
	public void clickAllowbutton()
	{
		driver.findElement(allowButton).click();
	}
	public void popupNumberenter(String number) {
		driver.findElement(popupNumber).sendKeys(number);
	}
	public void clickContinuebutton()
	{
		driver.findElement(popupContinue).click();
	}
	
}
