package com.google.pac;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class testforquikr {
  @Test
  public void f() throws InterruptedException {
	  WebDriver driver;
	  WebDriverManager.chromedriver().setup();
	  driver=new ChromeDriver();	  
	  driver.get("https://www.zomato.com/");
	  //driver.manage().window().maximize();
	  Thread.sleep(10000);
//	  driver.findElement(By.xpath("/html/body/div[8]/div[2]/div[2]/button[2]"));
//	  driver.findElement(By.linkText("Login/Register"));
//	  driver.findElement(By.xpath("//input[@type='text']")).sendKeys("9072037468");
  }
}
