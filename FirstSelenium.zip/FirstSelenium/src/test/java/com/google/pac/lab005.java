package com.google.pac;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;
public class lab005 {
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		
		//PART1
		driver.get("http://demo.opencart.com/");
		driver.manage().window().maximize();
		if(driver.getTitle().equals("Your Store")) {
			System.out.println("Title is correct");
		}
		else {
			System.out.println("Title is not correct");
		}
		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(By.linkText("Register")).click();
		
		if(driver.findElement(By.xpath("//h1[text()='Register Account']")).isDisplayed()) {
			System.out.println("Register Account is displayed");
		}else {
			System.out.println("Register Account is not displayed");
		}
		
		driver.findElement(By.cssSelector(".btn.btn-primary")).submit();
		try {
		if(driver.findElement(By.linkText("Warning: You must agree to the Privacy Policy!")).isDisplayed()) {
			System.out.println("warning message displayed");
		}
		
		else {
			System.out.println("no warning message is displayed");
		}
		}
		catch(Exception e) {	
		}
		Thread.sleep(2000);
		
		//PART2
		driver.findElement(By.name("firstname")).sendKeys("Arnold");
		
//		Thread.sleep(3000);
//		driver.findElement(By.cssSelector(".btn.btn-primary")).submit();
		
		driver.findElement(By.name("lastname")).sendKeys("Schembak");
//		Thread.sleep(2000);		
//		driver.findElement(By.cssSelector(".btn.btn-primary")).submit();
		
		driver.findElement(By.name("email")).sendKeys("arnmbk@gmail.com");
		
		//PART3
		driver.findElement(By.name("password")).sendKeys("9864857889");
		
		Thread.sleep(3000);
		
		//PART4
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("window.scrollBy(0,200)");
		
		Thread.sleep(2000);
		driver.findElement(By.id("input-newsletter-yes")).click();
		Thread.sleep(2000);
		driver.findElement(By.name("agree")).click();
		Thread.sleep(2000);
		driver.findElement(By.cssSelector(".btn.btn-primary")).submit();
		
		
		Thread.sleep(3000);
		driver.quit();
	}
}
