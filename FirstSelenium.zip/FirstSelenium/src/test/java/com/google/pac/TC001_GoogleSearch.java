package com.google.pac;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TC001_GoogleSearch {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com/");
		driver.findElement(By.name("q")).sendKeys("Selenium software");
		driver.findElement(By.name("q")).submit();
		System.out.println("The title of page is : "+driver.getTitle());
		System.out.println("The Current URL: "+driver.getCurrentUrl());
		System.out.println("Page Source: "+driver.getPageSource());
		driver.navigate().to("https://www.yahoo.com/");
		System.out.println("The title of page is : "+driver.getTitle());
		driver.navigate().refresh();
		Thread.sleep(2000);
		driver.navigate().back();
		System.out.println("The title of page is : "+driver.getTitle());
		Thread.sleep(2000);
		driver.navigate().forward();
		System.out.println("The title of page is : "+driver.getTitle());
		
		driver.quit();
		}

}
