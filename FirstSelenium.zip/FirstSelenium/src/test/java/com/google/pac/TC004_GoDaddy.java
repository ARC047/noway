package com.google.pac;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import org.testng.Assert;
import io.github.bonigarcia.wdm.WebDriverManager;

public class TC004_GoDaddy {
	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.godaddy.com/");
        driver.manage().window().maximize();

        
        String expectedTitle = "Domain Names, Websites, Hosting & Online Marketing Tools - GoDaddy IN";
        String actualTitle = driver.getTitle();
        if (actualTitle.equals(expectedTitle)) {
            System.out.println("Title is as expected.");
        } else {
            System.out.println("Title is not as expected.");
        }
        
        String expectedURL = "https://www.godaddy.com/en-in";
        String actualURL = driver.getCurrentUrl();
        System.out.println(actualURL);
        if (actualURL.equals(expectedURL)) {
            System.out.println("URL is as expected.");
        } else {
            System.out.println("URL is not as expected.");
        }

        String pageSource = driver.getPageSource();
        if (pageSource.contains(expectedTitle)) {
            System.out.println("Title is present in page source.");
        } else {
            System.out.println("Title is not present in page source.");
        }

        
	}
	
}
