package com.google.pac;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TC002_OpenCart {

	public static void main(String[] args) {
	
		WebDriverManager.firefoxdriver().setup();
		WebDriver driver=new FirefoxDriver();
		driver.get("https://demo.opencart.com/");
		
		String expectedTitle = "Your Store";
        String actualTitle = driver.getTitle();
        if (actualTitle.equals(expectedTitle)) {
            System.out.println("Title is correct " + actualTitle);
        } else {
            System.out.println("Title is incorrect " + actualTitle);
        }

		
		driver.quit();
	}
}
