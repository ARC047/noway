package com.example.player.bean;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table
public class Player {
	
	@Id
	@Column(length=20)
	private int playerId;
	@Column(length=50)
	private String playerName;
	@Column(length=50)
	private String sports;
	@Column(length=50)
	private String country;
	
	public Player() {
		super();
	}
	
	public Player(int playerId, String playerName, String sports, String country) {
		super();
		this.playerId = playerId;
		this.playerName = playerName;
		this.sports = sports;
		this.country = country;
	}
	
	public String getPlayerId() {
		return Integer.toString(playerId);
	}
	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}
	public String getPlayerName() {
		return playerName;
	}
	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}
	public String getSports() {
		return sports;
	}
	public void setSports(String sports) {
		this.sports = sports;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	
	

}
