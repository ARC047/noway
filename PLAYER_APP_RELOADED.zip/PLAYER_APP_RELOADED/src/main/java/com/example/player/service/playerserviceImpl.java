package com.example.player.service;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.player.bean.Player;
import com.example.player.repository.playerRepository;



@Service
public class playerserviceImpl implements playerservice{

	@Autowired
	private playerRepository playerRepo;
	
	
	//@Override
	public Player addplayer(Player play) {
		// TODO Auto-generated method stub
		Player pla = playerRepo.save(play);
		return pla;
	}

	//@Override
	public List<Player> getallplayers() {
		// TODO Auto-generated method stub
		return playerRepo.findAll();
	}

	//@Override
	public Player updateplayer(Player play) {
		// TODO Auto-generated method stub
		if(playerRepo.existsById(play.getPlayerId())) {
			playerRepo.save(play);
			return play;
		}
		
		return null;
	}

	//@Override
	public Player deleteplayerbyid(int playerId) {
		// TODO Auto-generated method stub
		if(playerRepo.existsById(Integer.toString(playerId))) {
			Player pla = playerRepo.findById(Integer.toString(playerId)).get();
			playerRepo.deleteById(Integer.toString(playerId));
			return pla;
		}
		return null;
	}

	@Override
	public Player getplayerbyid(int playerId) {
		// TODO Auto-generated method stub
		Optional<Player> playerdata = playerRepo.findById(Integer.toString(playerId));
		if(playerdata.isPresent())
			return playerdata.get();
		else
			return null;
	}
	
	@Override
	public Player dynamicUpdatePlayer(int playerId, Map<String, Object> updates) {
	    Player player = playerRepo.findById(Integer.toString(playerId)).orElse(null);
	    if (player != null) {
	        // Iterate through the updates map and apply changes to the player object
	        for (Map.Entry<String, Object> entry : updates.entrySet()) {
	            String field = entry.getKey();
	            Object value = entry.getValue();
	            switch (field) {
	                case "playerName":
	                    player.setPlayerName((String) value);
	                    break;
	                case "country":
	                    player.setCountry((String) value);
	                    break;
	                case "sports":
	                    player.setSports((String) value);
	                    break;
	                // Add more cases for other fields as needed
	            }
	        }
	        playerRepo.save(player);
	        return player;
	    }
	    return null;
	}

}
