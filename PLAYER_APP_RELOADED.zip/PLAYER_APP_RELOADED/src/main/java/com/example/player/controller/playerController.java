package com.example.player.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.player.bean.Player;
import com.example.player.service.playerserviceImpl;



@RestController
@RequestMapping("/api/v1/player")
public class playerController {
	
	@Autowired
	private playerserviceImpl playerService;
	
	@PostMapping
	public ResponseEntity<?> addplayer(@RequestBody Player play){
		System.out.println(play);
		Player pla = playerService.addplayer(play);
		if(pla!=null) {
			return new ResponseEntity<Player>(pla,HttpStatus.CREATED);
		}
		
		return new ResponseEntity<String>("Player already exists.",HttpStatus.CONFLICT);
		
	}
	
	@GetMapping
	public ResponseEntity<?> getallplayers() {
		
		List<Player> playerlist = playerService.getallplayers();
		
		if(playerlist.size() > 0) {
			return new ResponseEntity<List<Player>>(playerlist,HttpStatus.OK);
		}

		return new ResponseEntity<String>("List is empty",HttpStatus.OK);
		
	}
	
	@PutMapping
	public ResponseEntity<?> updateplayer(@RequestBody Player play) {
		
		Player updateplayer = playerService.updateplayer(play);
		if( updateplayer !=null) {
			return new ResponseEntity<Player>(updateplayer,HttpStatus.OK);
		}
		
		return new ResponseEntity<String>("Player does not exist",HttpStatus.CONFLICT);

	}
	
	@DeleteMapping("/{playerId}")
	public ResponseEntity<?> deleteplayerbyid(@PathVariable int playerId) {
		
		Player deleteplayer = playerService.deleteplayerbyid(playerId);;
		if( deleteplayer !=null) {
			return new ResponseEntity<Player>(deleteplayer,HttpStatus.OK);
		}
		
		return new ResponseEntity<String>("Player does not exist in the list or list is empty",HttpStatus.CONFLICT);
		

	}
	
	@GetMapping("/{playerId}")
	public ResponseEntity<?> getplayerbyid(@PathVariable int playerId ) {
		
		Player pla = playerService.getplayerbyid(playerId);
		
		if(pla != null) {
			return new ResponseEntity<Player>(pla,HttpStatus.OK);
		}

		return new ResponseEntity<String>("Player does not exist",HttpStatus.OK);
		
	}
	
	@PatchMapping("/{playerId}")
	public ResponseEntity<?> dynamicUpdatePlayer(@PathVariable int playerId, @RequestBody Map<String, Object> updates) {
	    Player updatedPlayer = playerService.dynamicUpdatePlayer(playerId, updates);
	    if (updatedPlayer != null) {
	        return new ResponseEntity<>(updatedPlayer, HttpStatus.OK);
	    }
	    return new ResponseEntity<>("Player not found", HttpStatus.NOT_FOUND);
	}
	

}
