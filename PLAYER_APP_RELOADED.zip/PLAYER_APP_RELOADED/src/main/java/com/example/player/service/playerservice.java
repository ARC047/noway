package com.example.player.service;

import java.util.List;
import java.util.Map;

import com.example.player.bean.Player;


public interface playerservice {
	
	public Player addplayer(Player play);
	public List<Player> getallplayers();
	public Player updateplayer(Player play);
	public Player deleteplayerbyid(int playerId);
	public Player getplayerbyid(int playerId);
	Player dynamicUpdatePlayer(int playerId, Map<String, Object> updates);

}
