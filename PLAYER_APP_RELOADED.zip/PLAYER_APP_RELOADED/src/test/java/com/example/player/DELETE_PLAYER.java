package com.example.player;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;
import io.restassured.response.Response; 


public class DELETE_PLAYER {
  @Test
  public void DeletePlayerById() {
      baseURI = "http://localhost:9003";

      Response response =
          given()
          .when()
              .delete("/api/v1/player/{playerId}", 3);
      
      response.then()
          .statusCode(200);

      response.body().prettyPrint();
      System.out.println("Player deleted successfully.");
  
  }
}
