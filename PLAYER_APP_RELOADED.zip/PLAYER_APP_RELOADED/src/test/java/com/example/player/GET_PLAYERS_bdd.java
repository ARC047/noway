package com.example.player;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import io.restassured.response.Response;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;
public class GET_PLAYERS_bdd {
 @Test
 public void getplayers() {
 baseURI="http://localhost:9003";
 Response response =
 given()
 .when()
 .get("/api/v1/player");
 response.then()
 .statusCode(200)
 .body("size()", greaterThan(0));
 response.body().prettyPrint();
 }
}