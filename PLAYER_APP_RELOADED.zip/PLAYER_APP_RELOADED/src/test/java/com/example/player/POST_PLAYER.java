package com.example.player;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

import static io.restassured.RestAssured.*;

public class POST_PLAYER {
  @Test
  public void testPostPlayer() {
      baseURI = "http://localhost:9003";
      String newPlayerJson = "{ \"playerId\": \"3\", \"playerName\": \"Edwin\", \"sports\": \"Swimming\", \"country\": \"Cuba\" }";

      Response response =
          given()
              .contentType(ContentType.JSON)
              .body(newPlayerJson)
          .when()
              .post("/api/v1/player");
      
      response.then()
          .statusCode(201);

      response.body().prettyPrint();
      System.out.println("New player added successfully.");
  }
}
