package com.example.player;

import org.testng.annotations.Test;
import org.testng.annotations.Test;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

import static io.restassured.RestAssured.*;

public class PATCH_PLAYER {
    @Test
    public void patch_partial_player() {
        baseURI = "http://localhost:9003";
        String partialPlayerJson = "{\"country\": \"UK\" }";
        
        Response response =
            given()
                .contentType(ContentType.JSON)
                .body(partialPlayerJson)
            .when()
                .patch("/api/v1/player/{playerId}", 2);
        
        response.then()
            .statusCode(200);

        response.body().prettyPrint();
        System.out.println("Player partially updated successfully.");
    }
}
