package com.example.player;

import org.testng.annotations.Test;
import org.testng.annotations.Test;


import io.restassured.http.ContentType;
import io.restassured.response.Response;

import static io.restassured.RestAssured.*;


public class UPDATE_PLAYER {
  @Test
  public void patch_player() {
	  baseURI = "http://localhost:9003";
      String partialPlayerJson = "{\"sports\" : \"TT\" , \"country\": \"Canada\" }";
      Response response =
              given()
                  .contentType(ContentType.JSON)
                  .body(partialPlayerJson)
              .when()
                  .put("/api/v1/player/{playerId}", 2);
          
          response.then()
              .statusCode(200);

          response.body().prettyPrint();
          System.out.println("Player partially updated successfully.");
  }
}
