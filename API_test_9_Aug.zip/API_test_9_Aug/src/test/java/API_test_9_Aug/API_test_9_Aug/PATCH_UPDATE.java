package API_test_9_Aug.API_test_9_Aug;

import org.testng.annotations.Test;
import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import io.restassured.http.ContentType;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;

public class PATCH_UPDATE {
  @Test
  public void PutUpdate() {
	  JSONObject req= new JSONObject();
	  req.put("name","Kavya" );
	  req.put("job","Dev");
	  baseURI="https://reqres.in";
	  given()
	  .header("Content-Type","application/json")
	  .contentType(ContentType.JSON)
	  .accept(ContentType.JSON)
	  .body(req.toJSONString())
	  .when().patch("/api/user/2")
	  .then()
	  .statusCode(200).body("name",equalTo("Kavya"))
	  .log().all();
	  }
}
