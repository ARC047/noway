package API_test_9_Aug.API_test_9_Aug;

import org.testng.annotations.Test;
import static org.hamcrest.CoreMatchers.equalTo;

import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;
public class GET_LISTUSER_BDD {
  @Test
  public void f() {
	  baseURI="https://reqres.in/api";
	  given().
	  get("users?page=2").
	  then().
	  statusCode(200).body("data[0].first_name",equalTo("Michael"));
  }
}
