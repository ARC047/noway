package API_test_9_Aug.API_test_9_Aug;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;

public class DELETE_USER {
  @Test
  public void f() {
	  baseURI="https://reqres.in";
	  given().
	  when().delete("/api/users/2").then().statusCode(204).log().all();
			  
			  
  }
}
