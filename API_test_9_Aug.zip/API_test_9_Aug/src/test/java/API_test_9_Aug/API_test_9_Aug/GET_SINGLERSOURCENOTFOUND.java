package API_test_9_Aug.API_test_9_Aug;

import org.testng.annotations.Test;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class GET_SINGLERSOURCENOTFOUND {
  @Test
  public void GetSingleResourceNotFound() {
	  Response res=RestAssured.get("https://reqres.in/api/users?delay=3");
	  System.out.println("Status Code: "+res.getStatusCode());
	  System.out.println("Response Time:  "+res.getTime());
	  System.out.println("Response Bod: "+res.getBody().asString());
	  System.out.println("Status Line: "+res.getStatusLine());
	  System.out.println("Header: "+res.getHeader("content-type"));
	  
  }
}
