package API_test_9_Aug.API_test_9_Aug;

import org.testng.annotations.Test;
import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;



public class POST_USER_BDD {
  @Test
  public void PostUser() {
	  JSONObject req= new JSONObject();
	  req.put("name","Deepika" );
	  req.put("job","Dev");
	  baseURI="https://reqres.in/api";
	  given().body(req.toJSONString()).when().post("/user").then().statusCode(201).log().all();
	  }
}
